const info = {
    usuario: {
        id: 1,
        email: "martin@gmail.com",
        nombre: "Martin",
        contraseña: "12345",
        fecha_nacimiento: "20/10/04",
        documento: 45787453,
        foto_perfil: "",
    },
    productos: [
        {
            imagen:"reloj-1.jpeg",
            nombre_producto: "ROLEX GMT-MASTER II",
            descripcion: "Root Beer de 40mm 2024",
            comentarios: [
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                }
            ]
        },
        {
            imagen:"reloj-2.jpeg",
            nombre_producto: "ROLEX YACHT-MASTER",
            descripcion: "Yacht-Master Perpetual Date 40mm 2023",
            comentarios: [
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                }
            ]
        },
        {
            imagen:"reloj-3.jpeg",
            nombre_producto: "ROLEX DAYTONA",
            descripcion: "Oyster Perpetual Cosmograph de 40mm 2021",
            comentarios: [
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                }
            ]
        },
        {
            imagen:"reloj-4.jpeg",
            nombre_producto: "ROLEX DAY-DATE",
            descripcion: "Day Date Oyster Perpetual de 40mm 2021",
            comentarios: [
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                }
            ]
        },
        {
            imagen:"reloj-5.webp",
            nombre_producto: "CARTIER",
            descripcion: "Panthère de 31mm de archivo",
            comentarios: [
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                }
            ]
        },
        {
            imagen:"reloj-6.webp",
            nombre_producto: "JAEGER-LECOULTRE",
            descripcion: "Etrier de 23mm 1970",
            comentarios: [
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                }
            ]
        },
        {
            imagen:"reloj-7.webp",
            nombre_producto: "AUDEMARS PIGUET",
            descripcion: "Royal Oak Openworked de 41mm",
            comentarios: [
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                }
            ]
        },
        {
            imagen:"reloj-8.webp",
            nombre_producto: "PATEK PHILIPPE",
            descripcion: "Nautilus '40th Anniversary' de 40.5mm 2018",
            comentarios: [
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                }
            ]
        },
        {
            imagen:"reloj-9.webp",
            nombre_producto: "RICHARD MILLE",
            descripcion: "RM 67-02 Sébastien Ogier de 38.7mm 2019",
            comentarios: [
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                }
            ]
        },
        {
            imagen:"reloj-10.webp",
            nombre_producto: "PATEK PHILIPPE",
            descripcion: "Nautilus de 40mm 1973",
            comentarios: [
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                },
                {
                    nombre_usuario: "Marcos",
                    texto_comentario: "el mejor reloj que me compre en mi vida.",
                    imagen_perfil: ""
                }
            ]
        }
    ]
}

module.exports = info